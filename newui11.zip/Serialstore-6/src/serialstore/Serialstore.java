/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serialstore;


import java.io.IOException;
import java.util.Timer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.*;
import java.sql.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * 
 * 
 */
public class Serialstore extends TransactionController {

    private static void InsertToTable() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
    
TransactionController test = new TransactionController();
        Customer customer = new Customer("Lehar", "PSU", 1234123, 10000);

         public static void connection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
                        //System.out.println("");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
     
                }
         }
         
         public static Connection ConnectionToMySql(){
		connection();
		//String host = "jdbc:mysql://localhost/PointOfSale";
                String host = "jdbc:mysql://localhost:9000/PointOfSale";
		String Username = "root";
		String Password = "root";
		try {
			Connection connect = DriverManager.getConnection(host, Username, Password);
			return connect;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
         public static void Runcode() throws SQLException {
            TransactionController object = new TransactionController();
            Sale sale= new Sale();
            Order order = new Order();
            Exchange exchange = new Exchange();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));             
            Connection conn = ConnectionToMySql();
            int input = 1;
            String userInput = "";
            while(input!=5){
            int transactionID = 1;
            System.out.println("Connection Verified.");
            System.out.println("MAIN MENU\nPress 1 to make a new sale\nPress 2 to view inventory\nPress 3 to return or exchange\nPress 4 to exit system");
            try{
                userInput = bufferedReader.readLine();
                input = Integer.parseInt(userInput);
             if(input==1){
                Transaction[] transaction;
                transaction = new Transaction[10];
                transaction[0]=new Sale();
                transaction[0].start();
                try
		{
			Thread.sleep(10000);
		}
		catch(InterruptedException e) {}
             }
             else if(input==2){
                 Statement stmt = conn.createStatement();
                 System.out.println("Displaying current inventory...");
               ResultSet rs = stmt.executeQuery("SELECT * from Inventory");
               while ( rs.next() ) {
			String itemName = rs.getString("itemName");
			String itemPrice = rs.getString("ItemPrice");
                        String itemID = rs.getString("itemID");
                        String quantity = rs.getString("quantity");
                        String freezequantity = rs.getString("freezequantity");
                        String description = rs.getString("description");
            
            System.out.println("itemName: "+ itemName + ","
                    + " itemPrice: " + itemPrice + ", "
                    + "itemID: " + itemID + ","
                    +" quantity" + quantity + ","
                    +"description" + description);
                }
                 rs.close();
             }
               /*System.out.println("Displaying current inventory...");
               ResultSet rs = stmt.executeQuery("SELECT * from Inventory");
               while ( rs.next() ) {
			String itemName = rs.getString("itemName");
			String itemPrice = rs.getString("ItemPrice");
                        String itemID = rs.getString("itemID");
                        String quantity = rs.getString("quantity");
                        String freezequantity = rs.getString("freezequantity");
                        String description = rs.getString("description");
            
            System.out.println("itemName: "+ itemName + ","
                    + " itemPrice: " + itemPrice + ", "
                    + "itemID: " + itemID + ","
                    +" quantity" + quantity + ","
                    +"description" + description);
                }
                 rs.close();*/
             
             else if(input==3){
               System.out.println("Returns and Exchanges");
               //exchange.returnItem();
             }
             else if(input==4){
               break;
             }
             else{
                 System.out.println("Invalid Input");
             }
            }
            catch (IOException e) {
        e.printStackTrace();
        }
            }
             
             
             
             
          //   Statement stmt = conn.createStatement();
//             ResultSet rs = stmt.executeQuery("INSERT INTO Random" + " VALUES(2) ");
//             while (rs.next()){
//                 String id = rs.getString("id");
//                 System.out.println("Unique ID = " +id);


//                 
                 
           
//    TransactionController test = new TransactionController();
//       
//        Customer customer = new Customer("Lehar", "PSU", 1234123, 10000);
//       
//        int i = 1;
//        while(i<1000000){
//           
//            
//            System.out.println("Start of Thread "+i);
//           Transaction trans1 = new Order(test.getInv1(), customer, "Feb9", "Visa", 1234567, 1);
//           Thread thread1 = new Thread(trans1);
//           try{
//               System.out.println("Sleeping");
//            Timer timer = new Timer();
//           Thread.sleep((int) (Math.random() * 1000));
//           
//           
//          
//      }catch(InterruptedException e){}
//        thread1.start();
//        i++;
//        }
//        
//
//
       }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException  {
       MainMenuCntl theMainMenuCntl = new MainMenuCntl(); 
      // ConnectionToMySql();
       //Serialstore.Runcode();
      // InsertToTable();
        
    //  ShowTable();
       //  TODO code application logic here
        
        //test.printinventory();
     

    }
    

}
