package serialstore;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lehar
 * 
 */
public class InventoryItem {
    private String itemName;
    private double itemPrice;
    private int itemID;
    private int quantity;
    private int freezequantity;
    private String description;
    
    InventoryItem(String a, double b, int c, int d){
        itemName = a;
        itemPrice = b;
        itemID = c; 
        quantity = d;
        freezequantity = 0;
    }

    /**
     * @return the itemName
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * @param itemName the itemName to set
     */
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    /**
     * @return the itemPrice
     */
    public double getItemPrice() {
        return itemPrice;
    }

    /**
     * @param itemPrice the itemPrice to set
     */
    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    /**
     * @return the itemID
     */
    public int getItemID() {
        return itemID;
    }

    /**
     * @param itemID the itemID to set
     */
    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    /**
     * @return the quantity
     */
    public synchronized int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public synchronized void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the freezequantity
     */
    public int getFreezequantity() {
        return freezequantity;
    }

    /**
     * @param freezequantity the freezequantity to set
     */
    public synchronized void setFreezequantity(int freezequantity) {
        this.freezequantity = freezequantity;
    }
    
    public  synchronized void changeFreeze(int freezeq){
        this.freezequantity += freezeq;
        
    }
}
