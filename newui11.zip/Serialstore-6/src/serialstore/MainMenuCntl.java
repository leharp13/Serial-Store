/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package serialstore;
import java.sql.*;
import static serialstore.Serialstore.ConnectionToMySql;
/**
 *
 * @author vrindabadami
 */
public class MainMenuCntl {
    private ViewMain theMainMenuUI = new ViewMain (this);
    public MainMenuCntl(){
        theMainMenuUI.setVisible(true);
    }
    public void returnHere(){
        theMainMenuUI.setVisible(true);
        
    }
    public void makeSale(){
        theMainMenuUI.setVisible(false);
        theMainMenuUI.dispose();
        Sale saleCntl = new Sale();
    }
    public void viewInventory(){
        theMainMenuUI.setVisible(false);
        theMainMenuUI.dispose();
        
        
    }
    public void makeExchange(){
        theMainMenuUI.setVisible(false);
        theMainMenuUI.dispose();
        Exchange exchangeCntl = new Exchange();
        
         
    }
    public void exitSystem(){
        theMainMenuUI.setVisible(false);
        theMainMenuUI.dispose();
        
    }
    
    
}
