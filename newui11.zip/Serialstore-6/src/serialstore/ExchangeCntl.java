/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package serialstore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static serialstore.Serialstore.ConnectionToMySql;

/**
 *
 * @author vrindabadami
 */
public class ExchangeCntl {
    private ViewExchangableUI ReturnUI = new ViewExchangableUI (this);
    private Exchange object = new Exchange();
    public ExchangeCntl(){
        ReturnUI.setVisible(true);
    }
    public void executeExhange1(String itemID2, String qty1){
        String itemID1 = itemID2;
        String qty2 = qty1;
        try{
        executeExchange(itemID1, qty2);}
        catch(SQLException e){
        }
    }
    public void executeExchange(String itemID2, String qty1) throws SQLException {
        Connection conn = ConnectionToMySql();
        Statement stmt = conn.createStatement();
        ResultSet rs1 = stmt.executeQuery("SELECT * from Inventory");
                 rs1.beforeFirst();
                 rs1.next();
        int quantity2  =Integer.parseInt(qty1);
                 String query3 = "update inventory set quantity = ? where itemID = "+itemID2;
                 String query4= "SELECT * FROM inventory WHERE itemID = "+itemID2;
                 PreparedStatement preparedStmt3 = conn.prepareStatement(query3);
                 PreparedStatement preparedStmt4 = conn.prepareStatement(query4);
                 String currentQuantity2 = rs1.getString("quantity");
                 int currentQty2 = Integer.parseInt(currentQuantity2);
                 int value2 = currentQty2-quantity2;
                 preparedStmt3.setInt(1, value2);
                 preparedStmt3.executeUpdate();
                 System.out.println("Updating quantity of inventory after exchange");
                 rs1.close();
                 int a = Integer.parseInt(itemID2);
                //executeTransaction(a);
            
}
    public void executeTransaction1(String itemID, String paymentOption, String name){
        String customerName = name;
        String itemID2 = itemID;
        String paymentType = paymentOption;
       
        try{
        executeTransaction(itemID, customerName, paymentType);}
        catch(SQLException e){
        }
    }
    public void executeTransaction(String itemID, String customerName, String paymentType) throws SQLException{
        Connection conn = ConnectionToMySql();
        Statement stmt = conn.createStatement();
        ResultSet rs2 = stmt.executeQuery("SELECT * from Transaction");
                 rs2.beforeFirst();
                 rs2.last();
        String currentTransactionID = rs2.getString("transactionID");
                 int newValue = Integer.parseInt(currentTransactionID);
                 int newTransactionID = newValue + 1;
                 String finalTransactionID = Integer.toString(newTransactionID);
                 rs2.beforeFirst();
                 rs2.next();
                 String name=customerName;
                 
                 int itemID2 = Integer.parseInt(itemID);
                 String paymentOption=paymentType;
                 
                 String query5 = "INSERT INTO Transaction VALUES('"+itemID2+"','"+name+"','"+finalTransactionID+"','"+paymentOption+"') ";
                 stmt.executeUpdate(query5);
                 System.out.println("New exchange transaction recorded");
                 rs2.close();
    }
}
