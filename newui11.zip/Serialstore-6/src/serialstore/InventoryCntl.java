/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package serialstore;
import java.sql.*;
import java.util.ArrayList;
import java.util.Vector;
import static serialstore.Serialstore.ConnectionToMySql;
/**
 *
 * @author vrindabadami
 */
public class InventoryCntl extends Transaction{
   
    public InventoryCntl(){
           
        }
    
    public void getTableData() throws SQLException{
        ArrayList columnNames = new ArrayList();
        ArrayList data = new ArrayList();
        String host = "jdbc:mysql://localhost:9000/PointOfSale";
		String Username = "root";
		String Password = "root";
		try {
			Connection connect = DriverManager.getConnection(host, Username, Password);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                String sql = "SELECT * FROM inventory";
                Connection conn = ConnectionToMySql();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * from Inventory");
            ResultSetMetaData md = rs.getMetaData();
            int columns = md.getColumnCount();
            //  Get column names
            for (int i = 1; i <= columns; i++)
            {
                columnNames.add( md.getColumnName(i) );
            }

            //  Get row data
            while (rs.next())
            {
                ArrayList row = new ArrayList(columns);
                  for (int i = 1; i <= columns; i++)
                {
                    row.add( rs.getObject(i) );
                }

                data.add( row );
            }
        Vector columnNamesVector = new Vector();
        Vector dataVector = new Vector();

        for (int i = 0; i < data.size(); i++)
        {
            ArrayList subArray = (ArrayList)data.get(i);
            Vector subVector = new Vector();
            for (int j = 0; j < subArray.size(); j++)
            {
                subVector.add(subArray.get(j));
            }
            dataVector.add(subVector);
        }

        for (int i = 0; i < columnNames.size(); i++ )
            columnNamesVector.add(columnNames.get(i));
        
    }
    }

