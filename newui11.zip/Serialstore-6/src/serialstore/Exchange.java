/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serialstore;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.*;
import java.sql.*;
import static serialstore.Serialstore.ConnectionToMySql;


public class Exchange extends Transaction {
private ViewExchangeUI ReturnUI = new ViewExchangeUI (this);
String customerName=" ";
private Thread t;

    public Exchange(){
        ReturnUI.setVisible(true);
    }
    public void run(){
      ReturnUI.setVisible(true);

    }
    public void startTheThread(){
        if(t==null){
            t = new Thread(this);
            t.start();
            System.out.println("Starting thread");
        }
    }
   
    public void returnItem1(String itemID, String quantity){
        ReturnUI.setVisible(true);
        String itemID2 = itemID;
        String qty2 = quantity;
        try{
         startTheThread();
        returnItem(itemID2, qty2);}
        catch(SQLException e){
        }
    }
    public void returnItem(String itemID1,String qty) throws SQLException{
        String x="";
        String choice="";
        String z="";
        String y="";
        int quantity  =Integer.parseInt(qty);
                Connection conn = ConnectionToMySql();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * from Inventory");
                 rs.beforeFirst();
                 rs.next();
                 String query1 = "update inventory set quantity = ? where itemID = "+itemID1;
                 String query2= "SELECT * FROM inventory WHERE itemID = "+itemID1;
                 PreparedStatement preparedStmt = conn.prepareStatement(query1);
                 PreparedStatement preparedStmt2 = conn.prepareStatement(query2);
                 String currentQuantity = rs.getString("quantity");
                 int currentQty = Integer.parseInt(currentQuantity);
                 int value = currentQty+quantity;
                 preparedStmt.setInt(1, value);
                 preparedStmt.executeUpdate();
                 System.out.println("Updated quantity of inventory returned.");
                 rs.close();
                 ResultSet rs1 = stmt.executeQuery("SELECT * from Inventory");
                 rs1.beforeFirst();
                 rs1.next();
                 int a = Integer.parseInt(itemID1);
                 try
		{
			Thread.sleep(1000);
                        System.out.println("THREAD SLEEPING.");

		}
		catch(InterruptedException e) {}
             
    }
    
    public void executeTransaction1(String itemID, String name){
        String customerName = name;
        String itemID2 = itemID;
        try{
        executeTransaction(itemID, customerName);}
        catch(SQLException e){
        }
    }
    public void executeTransaction(String itemID, String customerName) throws SQLException{
        Connection conn = ConnectionToMySql();
        Statement stmt = conn.createStatement();
        ResultSet rs2 = stmt.executeQuery("SELECT * from Transaction");
                 rs2.beforeFirst();
                 rs2.last();
        String currentTransactionID = rs2.getString("transactionID");
                 int newValue = Integer.parseInt(currentTransactionID);
                 int newTransactionID = newValue + 1;
                 String finalTransactionID = Integer.toString(newTransactionID);
                 rs2.beforeFirst();
                 rs2.next();
                 String name=customerName;
                 
                 int itemID2 = Integer.parseInt(itemID);
                 String paymentOption="Return (None)";
                 
                 String query5 = "INSERT INTO Transaction VALUES('"+itemID2+"','"+name+"','"+finalTransactionID+"','"+paymentOption+"') ";
                 stmt.executeUpdate(query5);
                 System.out.println("New return transaction recorded");
                 rs2.close();
    }
   
   
    
   

    
    
}
