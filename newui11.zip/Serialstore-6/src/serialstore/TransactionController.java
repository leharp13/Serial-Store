/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serialstore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Lehar
 * 
 */
public class TransactionController {
  
    private ArrayList<Transaction> transactionhistory = new ArrayList();
    private Inventory inv1;
    private Customer cus1;
    InventoryItem item1, item2, item3, item4, item5;
    
    //    Sale one;
//    Order two;
    
    TransactionController() {
        init();
        // this controls the transactions and checks all parameters 
        //  one.transactionstuff(3);
        //options();
    }

    public void init() {
        inv1 = new Inventory();
        item1 = new InventoryItem("Book", 100, 1234567, 25000000); // these are the inventory items examples. Name, price, id, Q
        item2 = new InventoryItem("Box", 150, 1234568, 5);
        item3 = new InventoryItem("Square", 200, 1234569, 10);
        item4 = new InventoryItem("Circle", 250, 1234560, 100);
        item5 = new InventoryItem("Rectangle", 300, 1234561, 80);
       /* getInv1().addtolist(item1);
        getInv1().addtolist(item2);
        getInv1().addtolist(item3);
        getInv1().addtolist(item4);
        getInv1().addtolist(item5);
*/
   //     cus1 = new Customer("Bob", "State College", 8676512, 200);// this is the customer value and money available

        // one = new Sale(inv1, cus1, "Jan1", 5140578, "Visa");
        //two = new Order(inv1, "Jan1", 5140578, "Visa");
    }

    //  public void options() {
    //  options();
    //   }
    public void printinventory() {  // prints details of all inventory
        /*for (int i = 0; i < getInv1().getInventorysize(); i++) {
            System.out.println("Item Name: " + getInv1().getInventoryID().get(i).getItemName()
                    + " Item Price: " + getInv1().getInventoryID().get(i).getItemPrice()
                    + " Item ID: " + getInv1().getInventoryID().get(i).getItemID()
                    + " Item Quantity: " + getInv1().getInventoryID().get(i).getQuantity()
                    + " Quantity Frozen: " + getInv1().getInventoryID().get(i).getFreezequantity());
        }
        */
    }

    public void addtohistory() {   // adding the specific transaction to the end of the list
System.out.println("osduhgsuhg");
    }
    public void addToInventory() throws SQLException{
        
    }
    public void returnItem() throws SQLException {
        
    }
    public void newSale() throws SQLException{
        
    }
    

    
    public ArrayList<Transaction> getTransactionhistory() {
        return transactionhistory;
    }

    /**
     * @return the inv1
     */
    /*public Inventory getInv1() {
        return inv1;
   }*/
    public void displayInventory(){
        
    }

    /**
     * @return the cus1
     */
    /*public Customer getCus1() {
        return cus1;
    }*/

}

//        int temp = 0;
//        Boolean firstcheck = false;
//        while (firstcheck != true) {
//            System.out.println("Press 1 to view inventory.\nPress 2 to make an order. \nPress 3 to make a sale. \nPress 0 to exit.");
//            if (reader.hasNextInt() != false) {
//                temp = reader.nextInt();
//                firstcheck = true;
//            } else {
//                reader.next();
//            }
//
//        }
//
//        if (temp == 1) {
//            printinventory();
//        } else if (temp == 2) {
//
//            int quantityrequest = 0;
//            int tempidnumber = 0;
//
//            Boolean checkserial = false;
//
//            while (checkserial != true) {
//                System.out.println("Enter the item ID");
//                if (reader.hasNextInt() != false) {
//                    tempidnumber = reader.nextInt();
//                    checkserial = true;
//                } else {
//                    System.out.println("This isnt't a number");
//                    reader.next();
//                }
//            }
//
//            Boolean check = false;
//
//            while (check != true) {
//                System.out.println("Enter quantity");
//                if (reader.hasNextInt() != false) {
//                    quantityrequest = reader.nextInt();
//                    check = true;
//                } else {
//                    reader.next();
//                }
//            }
//           two = new Order(inv1, "1", 1, "Visa");
//            two.orderstuff(tempidnumber, quantityrequest);
//         
//        } else if (temp == 0) {
//
//            System.exit(0);
//        }

