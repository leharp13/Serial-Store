/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serialstore;

import java.util.*;
import java.io.*;
import java.sql.*;
import static serialstore.Serialstore.ConnectionToMySql;
import static serialstore.Serialstore.connection;

/**
 *
 * @author Lehar
 * 
 */
public class Order extends Transaction {

    private String shipmenttype;
    private int tempproductid;
    private int tempquantityrequest;

    Order(){
        super();
    }
    
    public void displayInventory() throws SQLException{
       
        
    }
    /*public void freezeitem(int positioning, int customerorder) {

        Boolean testcheck = checkstock(positioning, customerorder);
        if (testcheck != false) {

            synchronized (a) {
           
                int x = getA().getInventoryID().get(positioning).getQuantity();
                int temp = x - customerorder;

                getA().getInventoryID().get(positioning).changeFreeze(customerorder);
                getA().getInventoryID().get(positioning).setQuantity(temp);
                System.out.println("Order processed");
            }
        } else {
            System.out.println("Order not processed");
        }
    }*/

    /*public void orderstuff(int requestid, int customerorder) {

        int positioning = checkid(requestid);      // Check ID goes through for loop to see if id exists.
        //   Boolean status = checkingprocess(positioning, customerorder);  // checks to make sure item is in stock
        Boolean status = true;                                          // and quantity requested does not exceed 
        // stock size

//        synchronized (this.getClass()) 
        synchronized(a){
        if (status != false) {

            freezeitem(positioning, customerorder); // puts item on freeze as part of order process.

            // generate randomized id for transaction
            transactionID = (((int) Math.random()) * 1000000) + (((int) Math.random()) * 100000)
                    + (((int) Math.random()) * 10000) + (((int) Math.random()) * 1000)
                    + (((int) Math.random()) * 100) + (((int) Math.random()) * 10);
//            System.out.println("Your order has been processed");

//                    else {
//            System.out.println("Your order did not go through. Either item does not exist or not enough to satsify order");
        }
        } 
    }*/

    /**
     * @return the shipmenttype
     */
    /*public String getShipmenttype() {
        return shipmenttype;
    }

    /**
     * @param shipmenttype the shipmenttype to set
     */
    /*public void setShipmenttype(String shipmenttype) {
        this.shipmenttype = shipmenttype;
    }*/

    @Override
    public void run() {
      //  System.out.println("Sleep time");
       // orderstuff(tempproductid, tempquantityrequest);
    }
}
