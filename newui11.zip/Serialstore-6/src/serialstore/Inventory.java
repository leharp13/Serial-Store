/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serialstore;

import java.util.ArrayList;

/**
 *
 * @author Lehar
 * 
 */
public class Inventory {

    private ArrayList<InventoryItem> InventoryID = new ArrayList();
    private int inventorysize;
    private double unitcost;

    Inventory() {
        inventorysize = 0;
    }

    public void addtolist(InventoryItem a) {
        getInventoryID().add(a);
        setInventorysize(getInventorysize() + 1);

    }

    /**
     * @return the InventoryID
     */
    public synchronized ArrayList<InventoryItem> getInventoryID() {
        return InventoryID;
    }

    /**
     * @param InventoryID the InventoryID to set
     */
    public void setInventoryID(ArrayList<InventoryItem> InventoryID) {
        this.InventoryID = InventoryID;
    }

    /**
     * @return the inventorysize
     */
    public int getInventorysize() {
        return inventorysize;
    }

    /**
     * @param inventorysize the inventorysize to set
     */
    public void setInventorysize(int inventorysize) {
        this.inventorysize = inventorysize;
    }

}
