/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serialstore;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.*;
import java.sql.*;
import static serialstore.Serialstore.ConnectionToMySql;

public class Sale extends Transaction {
BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));             Connection conn = ConnectionToMySql();
    private ViewSaleUI theMainMenuUI = new ViewSaleUI (this);
    private Thread t;
    
    public Sale(){
        theMainMenuUI.setVisible(true);
    }
    public void run(){
        
    }
    public void startTheThread(){
        if(t==null){
            t = new Thread(this);
            t.start();
            System.out.println("Starting thread");
        }
    }
    public void makeSale(String customerName, String itemNo, String qty, String paymentType){
        theMainMenuUI.setVisible(true);
        String customerName1 = customerName;
        String itemID = itemNo;
        String quantity = qty;
        String payment = paymentType;
                try{
                 startTheThread();
                 makeSale1(customerName1,itemID,quantity,payment);}
                 catch(SQLException x){
                }
        
    }
    
    public void makeSale1(String customerName, String itemNo, String qty, String paymentType) throws SQLException{
        Statement stmt = conn.createStatement();
                 int itemID = Integer.parseInt(itemNo);
                 String y="";
                 int quantity=Integer.parseInt(qty);
                 //System.out.println("Enter itemID to be sold");
                /* try{
                 x=bufferedReader.readLine();}
                 catch(IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
                 //itemID=Integer.parseInt(x);
                 /*System.out.println("Enter quantity to be sold");
                 try{
                 y=bufferedReader.readLine();}
                 catch(IOException e){
                     e.printStackTrace();
                 }
                 quantity=Integer.parseInt(y);*/
                 ResultSet rs = stmt.executeQuery("SELECT * from Inventory");
                 rs.beforeFirst();
                 rs.next();
                 String query1 = "update inventory set quantity = ? where itemID = "+itemNo;
                 String query2= "SELECT * FROM inventory WHERE itemID = "+itemNo;
                 //String query3 = query1;
                 //String query4 = query2;
                 PreparedStatement preparedStmt = conn.prepareStatement(query1);
                 PreparedStatement preparedStmt2 = conn.prepareStatement(query2);
                 String currentQuantity = rs.getString("quantity");
                 int currentQty = Integer.parseInt(currentQuantity);
                 int value = currentQty-quantity;
                 preparedStmt.setInt(1, value);
                 preparedStmt.executeUpdate();
                 System.out.println("Updating quantity of inventory sold");
                 rs.close();
                 ResultSet rs1 = stmt.executeQuery("SELECT * from Transaction");
                 rs1.beforeFirst();
                 rs1.last();
                 //String query4= "SELECT * FROM transaction";
                 //PreparedStatement preparedStmt4 = conn.prepareStatement(query4);
                 //preparedStmt4.executeQuery();
                 String currentTransactionID = rs1.getString("transactionID");
                 int newValue = Integer.parseInt(currentTransactionID);
                 int newTransactionID = newValue + 1;
                 String finalTransactionID = Integer.toString(newTransactionID);
                 rs1.beforeFirst();
                 rs1.next();
                 //String transactionNumber="";
                 //transactionNumber = Integer.toString(transactionID);
                 String name=customerName;
                 int itemID2=itemID;
                 //System.out.println("Enter payment type");
                 String paymentOption=paymentType;
                 /*try{
                 paymentOption=bufferedReader.readLine();}
                 catch(IOException e){
                     
                 }*/
                 String query3 = "INSERT INTO Transaction VALUES('"+itemID2+"','"+name+"','"+finalTransactionID+"','"+paymentOption+"') ";
                 stmt.executeUpdate(query3);
                 System.out.println("New transaction recorded");
                 rs1.close();
                 try
		{
			Thread.sleep(1000);
                        System.out.println("THREAD SLEEPING.");
		}
		catch(InterruptedException e) {}
                 
    }
    



//    public void transactionstuff(int requestid, int customerorder){
//        Boolean status = checkingprocess(requestid, customerorder);
//        int positioning = checkid(requestid);
//        
//        freezeitem(customerorder, positioning);
//
//        
//        if (status != false){
//           System.out.println("Your purchase is processed");
//        }
//    }
    
    
    
    
//    public boolean checkprice() {
//        double x = getA().getInventoryID().get(0).getItemPrice();
//        double y = getB().getMoney();
//        boolean check = true;
//        if (x > y) {
//            check = false;
//        }0
//        return check;
//    }
//
//    public boolean checkstock(int customerorder) {
//        int x = getA().getInventoryID().get(0).getQuantity();
//        int y = customerorder;
//        boolean check = true;
//
//        if (y > x) {
//            check = false;
//        }
//        return check;
//    }
//
//    public void freezeitem(int customerorder) {
//        int x = getA().getInventoryID().get(0).getQuantity();
//        int temp = x - customerorder;
//        getA().getInventoryID().get(0).setFreezequantity(customerorder);
//        getA().getInventoryID().get(0).setQuantity(temp);
//    }

    
}
